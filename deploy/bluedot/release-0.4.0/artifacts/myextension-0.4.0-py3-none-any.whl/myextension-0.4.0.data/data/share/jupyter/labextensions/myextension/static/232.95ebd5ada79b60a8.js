"use strict";(self.rspackChunkmyextension=self.rspackChunkmyextension||[]).push([[232],{8475(r,o,i){var e=i(1601),a=i.n(e),t=i(6314),p=i.n(t)()(a());p.push([r.id,`.jp-BehaviorAudit-editor,
.jp-BehaviorAudit-firstRun {
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
  padding: 24px;
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color0);
}

.jp-BehaviorAudit-editorHeader {
  display: flex;
  gap: 12px;
  align-items: center;
  justify-content: space-between;
  max-width: 880px;
  margin: 0 auto;
}

.jp-BehaviorAudit-editorHeader h1,
.jp-BehaviorAudit-firstRun h1 {
  margin: 0;
  font-size: var(--jp-content-font-size3);
  line-height: 1.4;
}

.jp-BehaviorAudit-steps {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  max-width: 880px;
  padding: 0;
  margin: 24px auto;
  list-style: none;
  border-block: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-step {
  padding: 12px;
  color: var(--jp-ui-font-color2);
  text-align: center;
}

.jp-BehaviorAudit-step[aria-current='step'] {
  color: var(--jp-ui-font-color1);
  font-weight: 600;
  box-shadow: inset 0 -2px var(--jp-brand-color1);
}

.jp-BehaviorAudit-step + .jp-BehaviorAudit-step {
  border-left: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-saveStatus,
.jp-BehaviorAudit-editorContent,
.jp-BehaviorAudit-firstRun {
  max-width: 880px;
  margin-right: auto;
  margin-left: auto;
}

.jp-BehaviorAudit-saveStatus {
  min-height: 20px;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
  text-align: right;
}

.jp-BehaviorAudit-editorContent h2,
.jp-BehaviorAudit-firstRun h2 {
  margin: 0 0 8px;
  color: var(--jp-ui-font-color1);
}

.jp-BehaviorAudit-editorContent p,
.jp-BehaviorAudit-firstRun p {
  line-height: 1.5;
}

.jp-BehaviorAudit-templateGrid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
  margin: 20px 0;
}

.jp-BehaviorAudit-templateCard {
  padding: 16px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-templateCard h3 {
  margin: 0 0 8px;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size2);
}

.jp-BehaviorAudit-templateCard p {
  min-height: 44px;
  margin: 0 0 16px;
  color: var(--jp-ui-font-color2);
}

.jp-BehaviorAudit-customEntry {
  margin-top: 4px;
}

.jp-BehaviorAudit-form {
  display: grid;
  gap: 16px;
  margin-top: 20px;
}

.jp-BehaviorAudit-dimensions {
  display: grid;
  gap: 16px;
}

.jp-BehaviorAudit-dimensionCard,
.jp-BehaviorAudit-addDimension {
  display: grid;
  gap: 12px;
  padding: 16px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-dimensionCardHeader {
  display: flex;
  gap: 12px;
  align-items: center;
  justify-content: space-between;
}

.jp-BehaviorAudit-dimensionCardHeader h3,
.jp-BehaviorAudit-addDimension h3 {
  margin: 0;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size2);
}

.jp-BehaviorAudit-dimensionAddActions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.jp-BehaviorAudit-field {
  display: grid;
  gap: 6px;
}

.jp-BehaviorAudit-label {
  color: var(--jp-ui-font-color1);
  font-weight: 600;
}

.jp-BehaviorAudit-input {
  box-sizing: border-box;
  width: 100%;
  min-height: 32px;
  padding: 6px 8px;
  color: var(--jp-ui-font-color1);
  font: inherit;
  background: var(--jp-input-background);
  border: 1px solid var(--jp-input-border-color);
  border-radius: var(--jp-border-radius);
}

.jp-BehaviorAudit-input:disabled {
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color2);
}

.jp-BehaviorAudit-input[aria-invalid='true'] {
  border-color: var(--jp-error-color1);
}

textarea.jp-BehaviorAudit-input {
  min-height: 72px;
  resize: vertical;
}

.jp-BehaviorAudit-fieldError {
  min-height: 18px;
  color: var(--jp-error-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-checkboxField {
  display: flex;
  gap: 8px;
  align-items: center;
}

.jp-BehaviorAudit-checkboxField input {
  width: 16px;
  height: 16px;
  margin: 0;
}

.jp-BehaviorAudit-examples,
.jp-BehaviorAudit-pilotDisclaimer,
.jp-BehaviorAudit-state {
  padding: 16px;
  margin: 16px 0;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-examples h3 {
  margin: 0 0 12px;
}

.jp-BehaviorAudit-examples p {
  margin: 8px 0;
}

.jp-BehaviorAudit-notice {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-state-error {
  border-color: var(--jp-error-color2);
}

.jp-BehaviorAudit-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  padding-top: 8px;
}

.jp-BehaviorAudit-inlineActions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
}

.jp-BehaviorAudit-actions-spread {
  justify-content: space-between;
}

.jp-BehaviorAudit-advancedSettings {
  min-width: 0;
  padding-top: 8px;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-advancedSettings summary {
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-weight: 600;
}

.jp-BehaviorAudit-advancedSettingsBody {
  display: grid;
  gap: 12px;
  padding-top: 12px;
}

.jp-BehaviorAudit-assistStatus {
  min-height: 20px;
  margin: 8px 0;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-assistStatus:empty {
  display: none;
}

.jp-BehaviorAudit-assistStatus-error {
  color: var(--jp-error-color1);
}

.jp-BehaviorAudit-candidateSection,
.jp-BehaviorAudit-confirmedSection {
  display: grid;
  gap: 12px;
  margin: 20px 0;
}

.jp-BehaviorAudit-candidateSection h3,
.jp-BehaviorAudit-confirmedSection > h3 {
  margin: 0;
  font-size: var(--jp-content-font-size2);
}

.jp-BehaviorAudit-suggestionCard {
  display: grid;
  gap: 8px;
  padding: 12px;
  border: 1px solid var(--jp-info-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-suggestionCard p {
  margin: 0;
  color: var(--jp-ui-font-color2);
}

.jp-BehaviorAudit-testPointLinks {
  display: grid;
  gap: 8px;
  min-width: 0;
  padding: 12px;
  border: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-testPointLinks legend {
  padding: 0 4px;
  color: var(--jp-ui-font-color1);
  font-weight: 600;
}

.jp-BehaviorAudit-button {
  min-height: 32px;
  padding: 6px 12px;
  color: var(--jp-ui-font-color1);
  font: inherit;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-button-primary {
  color: var(--jp-ui-inverse-font-color1);
  background: var(--jp-brand-color1);
  border-color: var(--jp-brand-color1);
}

.jp-BehaviorAudit-button-secondary:hover {
  background: var(--jp-layout-color2);
}

.jp-BehaviorAudit-button-primary:hover {
  background: var(--jp-brand-color0);
}

.jp-BehaviorAudit-button-danger {
  color: var(--jp-ui-inverse-font-color1);
  background: var(--jp-error-color1);
  border-color: var(--jp-error-color1);
}

.jp-BehaviorAudit-sidebar button,
.jp-BehaviorAudit-sidebar select,
.jp-BehaviorAudit-sidebar input,
.jp-BehaviorAudit-sidebar textarea {
  max-width: 100%;
}

.jp-BehaviorAudit-button:focus-visible,
.jp-BehaviorAudit-input:focus-visible,
.jp-BehaviorAudit-checkboxField input:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 2px;
}

.jp-BehaviorAudit-button:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}

.jp-BehaviorAudit-button[aria-busy='true'] {
  cursor: progress;
}

.jp-BehaviorAudit-statusBadge {
  display: inline-flex;
  align-items: center;
  min-height: 20px;
  padding: 2px 8px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  border: 1px solid var(--jp-border-color2);
  border-radius: 999px;
}

.jp-BehaviorAudit-statusBadge-neutral {
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color2);
}

.jp-BehaviorAudit-statusBadge-info {
  color: var(--jp-info-color0);
  border-color: var(--jp-info-color2);
}

.jp-BehaviorAudit-statusBadge-warning {
  color: var(--jp-warn-color0);
  border-color: var(--jp-warn-color2);
}

.jp-BehaviorAudit-statusBadge-success {
  color: var(--jp-success-color0);
  border-color: var(--jp-success-color2);
}

.jp-BehaviorAudit-statusBadge-danger {
  color: var(--jp-error-color0);
  border-color: var(--jp-error-color2);
}

.jp-BehaviorAudit-pilotDisclaimer {
  border-color: var(--jp-warn-color2);
}

.jp-BehaviorAudit-summary {
  display: grid;
  grid-template-columns: minmax(120px, 0.35fr) 1fr;
  gap: 8px 16px;
  padding: 16px 0;
  margin: 0;
}

.jp-BehaviorAudit-summary dt {
  color: var(--jp-ui-font-color2);
  font-weight: 600;
}

.jp-BehaviorAudit-summary dd {
  margin: 0;
}

.jp-BehaviorAudit-firstRun {
  height: auto;
  padding-top: 48px;
}

.jp-BehaviorAudit-firstRun h2 {
  margin-top: 24px;
  font-size: var(--jp-content-font-size2);
}

.jp-BehaviorAudit-sidebar {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  gap: 12px;
  padding: 12px;
  overflow: hidden auto;
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-sidebar h1,
.jp-BehaviorAudit-sidebar h2 {
  margin: 0;
  overflow-wrap: anywhere;
  font-size: var(--jp-ui-font-size2);
}

.jp-BehaviorAudit-sidebarSection,
.jp-BehaviorAudit-resultCard,
.jp-BehaviorAudit-resultEmpty,
.jp-BehaviorAudit-sidebarStatus {
  display: grid;
  gap: 8px;
  min-width: 0;
  padding: 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color0);
}

.jp-BehaviorAudit-sidebarStatus:empty {
  display: none;
}

.jp-BehaviorAudit-sidebar .jp-BehaviorAudit-pilotDisclaimer,
.jp-BehaviorAudit-sidebar p {
  margin: 0;
  overflow-wrap: anywhere;
  line-height: 1.45;
}

.jp-BehaviorAudit-knowledgePointList {
  display: grid;
  gap: 8px;
  margin: 0;
  padding-left: 20px;
}

.jp-BehaviorAudit-knowledgePointList li {
  overflow-wrap: anywhere;
}

.jp-BehaviorAudit-captureState,
.jp-BehaviorAudit-counts,
.jp-BehaviorAudit-resultSummary,
.jp-BehaviorAudit-evidenceMeta,
.jp-BehaviorAudit-notice {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-observationProgress {
  display: grid;
  gap: 6px;
  min-width: 0;
  padding: 8px 0;
  border-block: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-observationProgressSummary {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 8px;
  justify-content: space-between;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
}

.jp-BehaviorAudit-observationProgress progress {
  width: 100%;
  height: 8px;
  accent-color: var(--jp-brand-color1);
}

.jp-BehaviorAudit-observationProgressMeta,
.jp-BehaviorAudit-observationProgressComplete {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-observationProgressComplete {
  font-weight: 600;
}

.jp-BehaviorAudit-sessionLogs {
  display: grid;
  gap: 8px;
}

.jp-BehaviorAudit-sessionLogRow {
  display: grid;
  gap: 6px;
  min-width: 0;
  padding: 10px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-sessionLogHeader {
  display: flex;
  flex-wrap: wrap;
  gap: 6px 8px;
  align-items: flex-start;
  justify-content: space-between;
}

.jp-BehaviorAudit-sessionLogIdentity {
  display: grid;
  min-width: 0;
  gap: 2px;
}

.jp-BehaviorAudit-sessionLogFilename {
  min-height: auto;
  padding: 0;
  overflow-wrap: anywhere;
  color: var(--jp-brand-color1);
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  text-align: left;
  text-decoration: underline;
  border: 0;
  background: transparent;
}

.jp-BehaviorAudit-sessionLogFilename:disabled {
  color: var(--jp-ui-font-color2);
  text-decoration: none;
  background: transparent;
}

.jp-BehaviorAudit-sessionLogStatus {
  flex: 0 0 auto;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-sessionLogStatus-generating {
  color: var(--jp-info-color1);
}

.jp-BehaviorAudit-sessionLogStatus-ready {
  color: var(--jp-success-color1);
}

.jp-BehaviorAudit-sessionLogStatus-error {
  color: var(--jp-error-color1);
}

.jp-BehaviorAudit-logFolderControl {
  display: grid;
  gap: 8px;
  padding: 8px 0;
}

.jp-BehaviorAudit-logViewer {
  min-width: 0;
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color0);
}

.jp-BehaviorAudit-logViewer-header {
  display: flex;
  flex: 0 0 auto;
  gap: 12px;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

.jp-BehaviorAudit-logViewer-header > div {
  display: grid;
  gap: 4px;
  min-width: 0;
}

.jp-BehaviorAudit-logViewer-header span {
  overflow-wrap: anywhere;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-BehaviorAudit-logViewer-header
  .jp-BehaviorAudit-logViewer-downloadStatus:not(:empty) {
  color: var(--jp-error-color1);
}

.jp-BehaviorAudit-logViewer-content {
  box-sizing: border-box;
  min-width: 0;
  min-height: 0;
  padding: 16px;
  overflow: auto;
}

.jp-BehaviorAudit-logViewer-content pre {
  margin: 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.jp-BehaviorAudit-stopWarning {
  display: grid;
  gap: 8px;
  padding: 8px;
  border: 1px solid var(--jp-warn-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-warn-color3);
}

.jp-BehaviorAudit-stopWarning p {
  color: var(--jp-ui-font-color1);
}

.jp-BehaviorAudit-resultConclusion {
  color: var(--jp-ui-font-color1);
  font-weight: 700;
}

.jp-BehaviorAudit-teachingAction {
  padding-top: 8px;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-evidenceDetails,
.jp-BehaviorAudit-reviewDetails,
.jp-BehaviorAudit-analysisDetails,
.jp-BehaviorAudit-aiConfig,
.jp-BehaviorAudit-advancedData {
  min-width: 0;
  padding: 8px 0;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-evidenceDetails summary,
.jp-BehaviorAudit-reviewDetails summary,
.jp-BehaviorAudit-analysisDetails summary,
.jp-BehaviorAudit-aiConfig summary,
.jp-BehaviorAudit-advancedData summary {
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-weight: 600;
}

.jp-BehaviorAudit-evidenceList,
.jp-BehaviorAudit-reviewForm,
.jp-BehaviorAudit-aiConfig,
.jp-BehaviorAudit-advancedData,
.jp-BehaviorAudit-deleteSession {
  display: grid;
  gap: 8px;
  min-width: 0;
}

.jp-BehaviorAudit-evidenceList {
  padding-left: 20px;
  overflow-wrap: anywhere;
}

.jp-BehaviorAudit-evidenceList li {
  padding: 4px 0;
}

.jp-BehaviorAudit-reviewForm fieldset {
  display: grid;
  gap: 6px;
  min-width: 0;
  padding: 8px;
  border: 1px solid var(--jp-border-color2);
}

.jp-BehaviorAudit-choice {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  overflow-wrap: anywhere;
}

.jp-BehaviorAudit-reviewForm textarea.jp-BehaviorAudit-input {
  min-height: 72px;
  resize: vertical;
}

.jp-BehaviorAudit-advancedData > .jp-BehaviorAudit-button {
  margin-top: 8px;
}

.jp-SideBar.lm-TabBar.jp-mod-left[data-orientation='vertical']
  .lm-TabBar-tab.jp-BehaviorAudit-sidebarTab
  .lm-TabBar-tabLabel {
  writing-mode: vertical-rl;
  text-orientation: upright;
  transform: none;
}

@media (prefers-reduced-motion: reduce) {
  .jp-BehaviorAudit-sidebar * {
    scroll-behavior: auto;
  }
}

@media (width <= 640px) {
  .jp-BehaviorAudit-editor,
  .jp-BehaviorAudit-firstRun {
    padding: 16px;
  }

  .jp-BehaviorAudit-editorHeader {
    align-items: flex-start;
  }

  .jp-BehaviorAudit-steps {
    grid-template-columns: 1fr;
    margin: 16px auto;
  }

  .jp-BehaviorAudit-step {
    text-align: left;
  }

  .jp-BehaviorAudit-step + .jp-BehaviorAudit-step {
    border-top: 1px solid var(--jp-border-color2);
    border-left: 0;
  }

  .jp-BehaviorAudit-templateGrid {
    grid-template-columns: 1fr;
  }

  .jp-BehaviorAudit-dimensionCardHeader {
    align-items: flex-start;
  }

  .jp-BehaviorAudit-dimensionCardHeader .jp-BehaviorAudit-button,
  .jp-BehaviorAudit-dimensionAddActions .jp-BehaviorAudit-button {
    width: 100%;
  }

  .jp-BehaviorAudit-summary {
    grid-template-columns: 1fr;
    gap: 4px;
  }

  .jp-BehaviorAudit-summary dd + dt {
    margin-top: 8px;
  }

  .jp-BehaviorAudit-actions {
    justify-content: stretch;
  }

  .jp-BehaviorAudit-inlineActions,
  .jp-BehaviorAudit-actions-spread {
    align-items: stretch;
    justify-content: stretch;
  }

  .jp-BehaviorAudit-inlineActions .jp-BehaviorAudit-button {
    flex: 1 1 100%;
  }

  .jp-BehaviorAudit-actions .jp-BehaviorAudit-button {
    flex: 1 1 100%;
  }
}
`,""]),i.d(o,{},{A:p})},6314(r){r.exports=function(r){var o=[];return o.toString=function(){return this.map(function(o){var i="",e=void 0!==o[5];return o[4]&&(i+="@supports (".concat(o[4],") {")),o[2]&&(i+="@media ".concat(o[2]," {")),e&&(i+="@layer".concat(o[5].length>0?" ".concat(o[5]):""," {")),i+=r(o),e&&(i+="}"),o[2]&&(i+="}"),o[4]&&(i+="}"),i}).join("")},o.i=function(r,i,e,a,t){"string"==typeof r&&(r=[[null,r,void 0]]);var p={};if(e)for(var d=0;d<this.length;d++){var n=this[d][0];null!=n&&(p[n]=!0)}for(var s=0;s<r.length;s++){var u=[].concat(r[s]);e&&p[u[0]]||(void 0!==t&&(void 0===u[5]||(u[1]="@layer".concat(u[5].length>0?" ".concat(u[5]):""," {").concat(u[1],"}")),u[5]=t),i&&(u[2]&&(u[1]="@media ".concat(u[2]," {").concat(u[1],"}")),u[2]=i),a&&(u[4]?(u[1]="@supports (".concat(u[4],") {").concat(u[1],"}"),u[4]=a):u[4]="".concat(a)),o.push(u))}},o}},1601(r){r.exports=function(r){return r[1]}},5072(r){var o=[];function i(r){for(var i=-1,e=0;e<o.length;e++)if(o[e].identifier===r){i=e;break}return i}function e(r,e){for(var a={},t=[],p=0;p<r.length;p++){var d=r[p],n=e.base?d[0]+e.base:d[0],s=a[n]||0,u="".concat(n," ").concat(s);a[n]=s+1;var l=i(u),v={css:d[1],media:d[2],sourceMap:d[3],supports:d[4],layer:d[5]};if(-1!==l)o[l].references++,o[l].updater(v);else{var c=function(r,o){var i=o.domAPI(o);return i.update(r),function(o){o?(o.css!==r.css||o.media!==r.media||o.sourceMap!==r.sourceMap||o.supports!==r.supports||o.layer!==r.layer)&&i.update(r=o):i.remove()}}(v,e);e.byIndex=p,o.splice(p,0,{identifier:u,updater:c,references:1})}t.push(u)}return t}r.exports=function(r,a){var t=e(r=r||[],a=a||{});return function(r){r=r||[];for(var p=0;p<t.length;p++){var d=i(t[p]);o[d].references--}for(var n=e(r,a),s=0;s<t.length;s++){var u=i(t[s]);0===o[u].references&&(o[u].updater(),o.splice(u,1))}t=n}}},7659(r){var o={};r.exports=function(r,i){var e=function(r){if(void 0===o[r]){var i=document.querySelector(r);if(window.HTMLIFrameElement&&i instanceof window.HTMLIFrameElement)try{i=i.contentDocument.head}catch(r){i=null}o[r]=i}return o[r]}(r);if(!e)throw Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");e.appendChild(i)}},540(r){r.exports=function(r){var o=document.createElement("style");return r.setAttributes(o,r.attributes),r.insert(o,r.options),o}},5056(r,o,i){r.exports=function(r){var o=i.nc;o&&r.setAttribute("nonce",o)}},7825(r){r.exports=function(r){if("u"<typeof document)return{update:function(){},remove:function(){}};var o=r.insertStyleElement(r);return{update:function(i){var e,a,t;e="",i.supports&&(e+="@supports (".concat(i.supports,") {")),i.media&&(e+="@media ".concat(i.media," {")),(a=void 0!==i.layer)&&(e+="@layer".concat(i.layer.length>0?" ".concat(i.layer):""," {")),e+=i.css,a&&(e+="}"),i.media&&(e+="}"),i.supports&&(e+="}"),(t=i.sourceMap)&&"u">typeof btoa&&(e+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(t))))," */")),r.styleTagTransform(e,o,r.options)},remove:function(){var r;null===(r=o).parentNode||r.parentNode.removeChild(r)}}}},1113(r){r.exports=function(r,o){if(o.styleSheet)o.styleSheet.cssText=r;else{for(;o.firstChild;)o.removeChild(o.firstChild);o.appendChild(document.createTextNode(r))}}},8579(r,o,i){var e=i(5072),a=i.n(e),t=i(7825),p=i.n(t),d=i(7659),n=i.n(d),s=i(5056),u=i.n(s),l=i(540),v=i.n(l),c=i(1113),h=i.n(c),j=i(8475),g={};g.styleTagTransform=h(),g.setAttributes=u(),g.insert=n().bind(null,"head"),g.domAPI=p(),g.insertStyleElement=v(),a()(j.A,g),j.A&&j.A.locals&&j.A.locals}}]);